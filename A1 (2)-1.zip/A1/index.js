
/* scrollToTop function which is help to scroll the screen and the value 0 means scroll to the top of web page */
function scrollToTop() {
    document.documentElement.scrollTop = 0;
}


function popbtn() {
    document.getElementById("mymodal").style.display = "block";
}


function closebtn() {
    document.getElementById("mymodal").style.display = "none";
}

/* function opendoc() {
    document.getElementById("helptext").style.display = "block";
}

function closebtn2() {
    document.getElementById("helptext").style.display = "none";
} */